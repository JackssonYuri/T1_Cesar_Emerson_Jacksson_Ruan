#ifndef CLIENTE_H
#define CLIENTE_H


#define Nlinhas 7	
    
		void MenuFuncionario(void);
    void TelaConsulta(void);
    void TelaCliente (void);
    void TelaCompra(void);
    //void TelaPrincipal(void);
    void Bilhete(void);
    void ChecarIngresso(void);
    void matriz1(void);
  	void matriz2(void);
  	void matriz3(void);
  	void matriz4(void);
  	void matriz5(void);
		void RemoveFilme(void);
		void nomeFilme(void);
		void VisualizaSala(void);
		void MenuFuncionario(void);	
		void visualizaMatriz1(void);
  	void visualizaMatriz2(void);
  	void visualizaMatriz3(void);
  	void visualizaMatriz4(void);
  	void visualizaMatriz5(void);

#endif 